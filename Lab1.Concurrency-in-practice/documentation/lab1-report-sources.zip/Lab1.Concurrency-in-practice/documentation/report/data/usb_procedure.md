# USB measurement protocol, 25 October 2026

The user confirmed a separate safe eject, physical unplug, and reconnect before each of the 1-, 2-, and 4-thread measurements. The first eject initially failed because a VS Code shell had its working directory on the drive; the user changed directory before performing the first reconnect. Later ejections succeeded through diskutil.

Spotlight was disabled with `mdutil -i off /Volumes/ESD-USB`. Its disabled status was checked after every reconnect without opening the part files. No input-content read or hash was performed between the confirmed reconnect and the corresponding measurement. Each process received `/Volumes/ESD-USB` explicitly.

The timing records contain the observed wall time, peak RSS, printed sign counters, measurement timestamp, and command. All three runs agree on 24,996,544 negative, 25,003,426 positive, and 30 zero values.

The two historical dashboard sessions contain Task 2 entries whose storage/cache provenance is unverified; those rows are preserved but excluded from the cold-cache USB tables and conclusions. Separate Task 1a/1c correctness-validation runs are not substituted into the historical performance series.
