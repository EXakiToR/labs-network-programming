Lab 1 source bundle. Open Lab1.Concurrency-in-practice/documentation/README.md. The compiled report is delivered separately. Large datasets are excluded.
